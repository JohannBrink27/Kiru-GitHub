﻿//var testClick = function (bit) {
//    alert("Clicked!");
//};


function showHide() {
    var panel = document.getElementById("<%= InformationPanel.ClientID %>");

    if (panel != null) {
        if (panel.style.display == "block") {
            panel.style.display = "";
        }
        else if (panel.style.display == "") {
            panel.style.display = "block";
        }
    }

    return false;
};

